class Book:
    def __init__(self, b_id, b_score):
        self.b_id = b_id
        self.b_score = b_score
        self.is_scanned = False
